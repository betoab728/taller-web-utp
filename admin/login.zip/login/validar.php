<?php

$usuario=$_POST['usuario'];
$contraseña=$_POST['contraseña'];
session_start();
$_SESSION['usuario']=$usuario;

include('db.php');

$consulta="SELECT * FROM usuario where nombre='$usuario' and password='$contraseña'";
$resultado=mysqli_query($mysqli,$consulta);

$filas=mysqli_num_rows($resultado);



if($filas){
  
    header("location:home.php");

}
else{
    ?>
    <h1 class="bad">ERROR DE AUTENTIFICACION</h1>
    <?php
    include("index.html");

  ?>
  <?php
}
